<?php  ?>
<!DOCTYPE html>
<html>
<head>
<title>Products</title>
</head>
<body>
<div id='main'>
    <img src="/laptop1.jpeg" alt="img not available"><br> 
    <p>hp pavillion</p>
    <p>$5/day</p> 
    
    <img src="/laptop2.jpeg" alt="img not available">
    <p>hp-15s-fr5012tu
        intel-core-i3-12th-gen</p>
    <p>$9/day</p> 
    
    <img src="/dell laptop.jpg" width=500px height=500px alt="img available"><br>
    <p> Dell 15.6 Laptop PC with Intel Core i5 Processor <br>
        8GB Memory 500GB HDD Drive <br>
        Wi-Fi DVD and Windows 10 Pro Computer</p>
        <p>$12/day</p><br><br><br>

        <img src="/HP-Pavilion laptop.jpg" width=500px height=500px alt="img not available"><br>
        <p>Intel Core i5-8250U <br>
    Intel UHD Graphics 620 <br>
    15.6”, HD (1366 x 768), TN <br>
    16GB SSD + 1000GB HDD <br>
    8GB DDR4, 2400 MHz <br>s
    2.04 kg (4.5 lbs) <br>
        </p>
            <p>$15/day</p><br><br><br>

            <img src="/lenovo laptop.jpeg" width=500px height=500px alt="img not available"><br>
            <p>Intel Core i5 <br>
            Intel UHD Graphics 620 <br>
            8GB Memory <br>
            16GB SSD <br>
            </p>
            <p>$10/day</p><br><br>

</div>
laptop
</body>
</html>s
    s